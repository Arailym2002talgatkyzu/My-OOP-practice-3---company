public interface Nonprogrammer_member extends Member{
    String manage();
    void setDoingDuration(int day);
    void setPenalty(int penalty);
    void setBonus(int bonus);

}
