public interface Member {
    String work();
    String getSalary();
}
