public interface Programmer_member extends Member {
    String programs();
    int get_doing_duration();
    int getBonus();
    int getPenalty();
}
